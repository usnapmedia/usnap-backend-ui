<footer>
 	
</footer>
<!--Import jQuery before materialize.js-->
	  <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
	  <script type="text/javascript" src="js/materialize.min.js"></script>
	  <script src="//js.pusher.com/2.2/pusher.min.js" type="text/javascript"></script>
	  <script type="text/javascript" src="js/custom.js"></script>
	  <script src="bower_components/chartist/dist/chartist.min.js"></script>
	</body>
</html>